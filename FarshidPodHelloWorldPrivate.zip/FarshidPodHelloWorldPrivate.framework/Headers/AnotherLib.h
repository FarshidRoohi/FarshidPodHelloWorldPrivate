//
//  AnotherLib.h
//  AnotherLib
//
//  Created by Farshid on 5/18/21.
//

#import <Foundation/Foundation.h>

//! Project version number for AnotherLib.
FOUNDATION_EXPORT double AnotherLibVersionNumber;

//! Project version string for AnotherLib.
FOUNDATION_EXPORT const unsigned char AnotherLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnotherLib/PublicHeader.h>


